export const isBrowserIE = !!document.documentMode;

export const convertIntoArray = collection => Array.prototype.slice.call(collection);
